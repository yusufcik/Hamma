package uz.hov

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.media.*
import android.os.*

object Sched {
    private fun prefs(c: Context) = c.getSharedPreferences("alarms", Context.MODE_PRIVATE)

    private fun pi(c: Context, id: Int, title: String, text: String): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java)
            .putExtra("i", id).putExtra("t", title).putExtra("x", text)
        return PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun set(c: Context, id: Int, at: Long, title: String, text: String) {
        if (at <= System.currentTimeMillis()) return
        prefs(c).edit().putString(id.toString(), "$at\n$title\n$text").apply()
        val show = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        c.getSystemService(AlarmManager::class.java)
            .setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi(c, id, title, text))
    }

    fun cancel(c: Context, id: Int) {
        prefs(c).edit().remove(id.toString()).apply()
        c.getSystemService(AlarmManager::class.java).cancel(pi(c, id, "", ""))
    }

    fun restore(c: Context) {
        prefs(c).all.forEach { (k, v) ->
            val p = (v as String).split("\n", limit = 3)
            set(c, k.toInt(), p[0].toLong(), p[1], p.getOrElse(2) { "" })
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        c.getSharedPreferences("alarms", Context.MODE_PRIVATE).edit()
            .remove(i.getIntExtra("i", 0).toString()).apply()
        val s = Intent(c, AlarmService::class.java)
            .putExtra("t", i.getStringExtra("t")).putExtra("x", i.getStringExtra("x"))
        c.startForegroundService(s)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Sched.restore(c)
    }
}

class AlarmService : Service() {
    private var mp: MediaPlayer? = null
    private val h = Handler(Looper.getMainLooper())
    private var title = "Ish signali"
    private var text = "Ilovani oching"

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.hasExtra("t") == true) {
            title = i.getStringExtra("t") ?: title
            text = i.getStringExtra("x") ?: text
        }
        val nm = getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel("hov_alarm", "Ish signali", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        nm.createNotificationChannel(ch)

        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "hov_alarm")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(text)
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(1, n)

        if (mp == null) play()
        return START_NOT_STICKY
    }

    private fun play() {
        try {
            val a = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val m = MediaPlayer.create(this, R.raw.alarm, a, AudioManager.AUDIO_SESSION_ID_GENERATE)
            m.isLooping = true
            m.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
            m.start()
            mp = m
        } catch (e: Exception) {
            mp = null
        }
        h.postDelayed({ stopSelf() }, 10 * 60 * 1000L)
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        mp?.release()
        mp = null
        super.onDestroy()
    }
}
